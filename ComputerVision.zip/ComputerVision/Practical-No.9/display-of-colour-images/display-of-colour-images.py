# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import matplotlib.pyplot as plt  # Matplotlib for plotting

def display_images(image_path):
    """
    Load and display the original and RGB color images using OpenCV and Matplotlib.
    
    Args:
    - image_path: Path to the image file
    """
    try:
        # Load the color image
        image = cv2.imread(image_path)

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError(f"Error: Image not found at {image_path}. Please check the path.")

        # Convert the image from BGR to RGB format
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Create a figure to display the images
        plt.figure(figsize=(10, 5))

        # Display the original image (BGR format)
        plt.subplot(1, 2, 1)  # 1 row, 2 columns, 1st subplot
        plt.imshow(image)  # Show the original image
        plt.axis('off')  # Hide the axis
        plt.title('Original Image (BGR)')  # Title for the original image

        # Display the RGB image
        plt.subplot(1, 2, 2)  # 1 row, 2 columns, 2nd subplot
        plt.imshow(image_rgb)  # Show the RGB image
        plt.axis('off')  # Hide the axis
        plt.title('Color Image (RGB)')  # Title for the RGB image

        # Show the images
        plt.tight_layout()  # Adjust layout for better spacing
        plt.show()  # Show the images

    except FileNotFoundError as fnf_error:
        print(fnf_error)  # Print the error message for file not found
    except Exception as e:
        print(f"An unexpected error occurred: {e}")  # Catch any other exceptions

# Main code to execute the display function
if __name__ == "__main__":
    try:
        # Specify the path to your image file
        image_path = 'sample_image.jpg'  # Change this to the path of your image
        display_images(image_path)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
