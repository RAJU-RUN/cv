# Import the necessary libraries
import cv2  # OpenCV for image processing
import matplotlib.pyplot as plt  # Matplotlib for plotting

def convert_color_spaces(image_path):
    """
    Load an image and convert it between different color spaces.
    
    Args:
    - image_path: Path to the image file
    """
    try:
        # Load the color image in BGR format (OpenCV loads images in BGR by default)
        image = cv2.imread(image_path)

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError(f"Error: Image not found at {image_path}. Please check the path.")

        # Convert the image from BGR to RGB format
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Convert the image to Grayscale
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Convert the image to HSV
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        image_hsv_rgb = cv2.cvtColor(image_hsv, cv2.COLOR_HSV2RGB)  # Convert HSV back to RGB for displaying

        # Convert the image to LAB
        image_lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        image_lab_rgb = cv2.cvtColor(image_lab, cv2.COLOR_LAB2RGB)  # Convert LAB back to RGB for displaying

        # Create a figure to display the images
        plt.figure(figsize=(15, 10))

        # Display the original image (RGB format)
        plt.subplot(2, 2, 1)
        plt.imshow(image_rgb)
        plt.axis('off')
        plt.title('Original Image (RGB)', fontsize=14, pad=20)  # Add padding to the title

        # Display the Grayscale image
        plt.subplot(2, 2, 2)
        plt.imshow(image_gray, cmap='gray')
        plt.axis('off')
        plt.title('Grayscale Image', fontsize=14, pad=20)  # Add padding to the title

        # Display the HSV image (converted back to RGB for proper display)
        plt.subplot(2, 2, 3)
        plt.imshow(image_hsv_rgb)
        plt.axis('off')
        plt.title('HSV Image', fontsize=14, pad=20)  # Add padding to the title

        # Display the LAB image (converted back to RGB for proper display)
        plt.subplot(2, 2, 4)
        plt.imshow(image_lab_rgb)
        plt.axis('off')
        plt.title('LAB Image', fontsize=14, pad=20)  # Add padding to the title

        # Adjust the layout and space between titles and plots
        plt.tight_layout(pad=3.0)  # Add extra padding around plots and titles
        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)  # Print the error message for file not found
    except Exception as e:
        print(f"An unexpected error occurred: {e}")  # Catch any other exceptions

# Main code to execute the conversion function
if __name__ == "__main__":
    try:
        # Specify the path to your image file
        image_path = 'sample_image.jpg'  # Change this to the path of your image
        convert_color_spaces(image_path)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
