# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib
# pip install PyWavelets

# Import the necessary libraries
import cv2  # OpenCV for image processing
import matplotlib.pyplot as plt  # Matplotlib for plotting
import pywt  # PyWavelets for wavelet transform
import numpy as np  # NumPy for numerical operations

def perform_dwt(image_path):
    """
    Load an image, perform Discrete Wavelet Transform (DWT), and display the results.
    
    Args:
    - image_path: Path to the image file
    """
    try:
        # Load the image
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError(f"Error: Image not found at {image_path}. Please check the path.")

        # Perform DWT using Haar wavelet
        coeffs = pywt.dwt2(image, 'haar')

        # Unpack the coefficients
        cA, (cH, cV, cD) = coeffs

        # Create a figure to display the results
        plt.figure(figsize=(12, 8))

        # Display the Approximation coefficients
        plt.subplot(2, 2, 1)
        plt.imshow(cA, cmap='gray')
        plt.title('Approximation Coefficients (cA)')
        plt.axis('off')

        # Display the Horizontal detail coefficients
        plt.subplot(2, 2, 2)
        plt.imshow(cH, cmap='gray')
        plt.title('Horizontal Detail Coefficients (cH)')
        plt.axis('off')

        # Display the Vertical detail coefficients
        plt.subplot(2, 2, 3)
        plt.imshow(cV, cmap='gray')
        plt.title('Vertical Detail Coefficients (cV)')
        plt.axis('off')

        # Display the Diagonal detail coefficients
        plt.subplot(2, 2, 4)
        plt.imshow(cD, cmap='gray')
        plt.title('Diagonal Detail Coefficients (cD)')
        plt.axis('off')

        # Show the images
        plt.tight_layout()
        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)  # Print the error message for file not found
    except Exception as e:
        print(f"An unexpected error occurred: {e}")  # Catch any other exceptions

# Main code to execute the DWT function
if __name__ == "__main__":
    try:
        # Specify the path to your image file
        image_path = 'sample_image.jpg'  # Change this to the path of your image
        perform_dwt(image_path)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
