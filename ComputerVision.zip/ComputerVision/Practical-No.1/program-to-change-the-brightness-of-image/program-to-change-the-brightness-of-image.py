# Import commands for terminal:
# pip install opencv-python
# pip install numpy

# Import the necessary libraries
import cv2   # OpenCV for image processing
import numpy as np  # NumPy for array manipulation
import sys   # For system-specific parameters and functions (optional, for command-line usage)

# Function to adjust the brightness of the image
def change_brightness(image, value):
    """
    This function increases or decreases the brightness of an image.
    Args:
    - image: Input image in BGR format
    - value: Integer value to increase (>0) or decrease (<0) brightness
    """
    # Convert the image from BGR color space (OpenCV default) to HSV
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    
    # Split the HSV image into its three components: H, S, and V (Hue, Saturation, Value)
    h, s, v = cv2.split(hsv_image)
    
    # Add the value to the 'V' (Value) channel to adjust brightness
    v = cv2.add(v, value)
    
    # Ensure the pixel values stay in the range of [0, 255]
    v = np.clip(v, 0, 255)
    
    # Merge the adjusted 'V' channel back with the 'H' and 'S' channels
    hsv_image_adjusted = cv2.merge((h, s, v))
    
    # Convert the HSV image back to BGR color space for display
    final_image = cv2.cvtColor(hsv_image_adjusted, cv2.COLOR_HSV2BGR)
    
    return final_image

# Main code to load the image and adjust brightness
if __name__ == "__main__":
    # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
    image = cv2.imread('sample_image.jpg')
    
    # Check if the image was loaded properly
    if image is None:
        print("Error: Image not found. Make sure the image file exists in the same directory.")
    else:
        # Display the original image
        cv2.imshow('Original Image', image)
        
        # Adjust the brightness by a positive or negative value
        # Example: Increase brightness by 50
        brightness_value = 50  # You can also try negative values like -50 to decrease brightness
        bright_image = change_brightness(image, brightness_value)
        
        # Display the brightened image
        cv2.imshow('Brightened Image', bright_image)
        
        # Save the brightened image to a new file
        cv2.imwrite('brightened_image.jpg', bright_image)
        
        # Wait for the user to press a key and then close the display windows
        cv2.waitKey(0)
        cv2.destroyAllWindows()
