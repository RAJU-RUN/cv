# Import commands for terminal:
# pip install opencv-python
# pip install numpy

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for array manipulation

# Function to convert an image to grayscale and display it
def display_grayscale_image(image):
    """
    This function converts the input image to grayscale and displays it.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Convert the image to grayscale
        grayscale_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Display the grayscale image
        cv2.imshow('Grayscale Image', grayscale_image)

    except Exception as e:
        print(f"An error occurred while processing the image: {e}")

# Main code to load the image and display the grayscale version
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Display the original image
        cv2.imshow('Original Image', image)

        # Display the grayscale version of the image
        display_grayscale_image(image)

        # Wait for the user to press a key and then close the display windows
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
