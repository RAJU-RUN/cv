# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

# Function to apply low-pass filters
def apply_low_pass_filters(image):
    """
    This function applies various low-pass filters to the input image.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Apply Average Filter
        average_filter = cv2.blur(image, (5, 5))

        # Apply Weighted Average Filter
        kernel = np.array([[1, 2, 1], [2, 4, 2], [1, 2, 1]]) / 16
        weighted_average_filter = cv2.filter2D(image, -1, kernel)

        # Apply Median Filter
        median_filter = cv2.medianBlur(image, 5)

        # Display results
        plt.figure(figsize=(15, 10))

        plt.subplot(2, 2, 1)
        plt.title('Average Filter')
        plt.imshow(cv2.cvtColor(average_filter, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(2, 2, 2)
        plt.title('Weighted Average Filter')
        plt.imshow(cv2.cvtColor(weighted_average_filter, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(2, 2, 3)
        plt.title('Median Filter')
        plt.imshow(cv2.cvtColor(median_filter, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred while applying low-pass filters: {e}")

# Function to apply high-pass filters
def apply_high_pass_filters(image):
    """
    This function applies high-pass filters to the input image.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Apply Sobel Operator
        sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=5)
        sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=5)
        sobel = cv2.magnitude(sobel_x, sobel_y)

        # Apply Laplacian Operator
        laplacian = cv2.Laplacian(image, cv2.CV_64F)

        # Display results
        plt.figure(figsize=(10, 5))

        plt.subplot(1, 2, 1)
        plt.title('Sobel Filter')
        plt.imshow(sobel, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title('Laplacian Filter')
        plt.imshow(laplacian, cmap='gray')
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred while applying high-pass filters: {e}")

# Main code to load the image and apply filters
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Apply low-pass filters
        apply_low_pass_filters(image)

        # Apply high-pass filters
        apply_high_pass_filters(image)

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
